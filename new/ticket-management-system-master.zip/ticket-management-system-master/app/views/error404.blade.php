@extends('layouts.master-child')

@section('page-wrapper')
    <h1>The page isn't found. 404 Not Found</h1>
@stop
<?php

namespace Webxity;

use View,
    Auth,
    Redirect,
    Session,
    Validator,
    App,
    User,
    Request,
    Input,
    Response;

class DashboardController extends \BaseController
{

    public function __construct()
    {
        $this->beforeFilter('auth', [
            'except' => ['getLogin', 'postVerifylogin']
        ]);

        $this->beforeFilter('csrf', [
            'on' => 'post',
            'except' => 'postVerifylogin'
        ]);
    }


    public function getIndex()
    {
        //Check if user logged in
        if (!Auth::check()) {
            return Redirect::action(__CLASS__ . '@getLogin');

        } else {
            //User is Authenticated
            return View::make('dashboard', ["name" => Auth::user()->getName()]);
        }
    }


    public function postVerifylogin()
    {
        $user = [
            'email' => Input::get('email'),
            'password' => Input::get('password')
        ];

        if (Auth::attempt($user)) {
            return Redirect::to('/');

        } else {
            // validation not successful, send back to form
            return Redirect::to('login')->with('message', 'Login Failed');
        }
    }

    public function getDashboard()
    {
        return View::make('dashboard');
    }

    public function postAdduser()
    {

        $user = [
            'name' => Input::get('name'),
            'password' => Input::get('pass'),
            'email' => Input::get('email'),
            'role' => Input::get('role')
        ];

        $validator = Validator::make(
            $user,
            [
                'name' => 'required',
                'password' => 'required|min:4',
                'email' => 'required|email|unique:users',
                'role' => 'required'
            ]
        );

        $messages = "Submission Sucessfull";

        if ($validator->fails()) {
            // The given data did not pass validation
            $messages = $validator->messages();

        } else {

            // Create a new user in the database...
            $user['password'] = Hash::make($user['password']);
            $response = User::create($user);
        }

        return View::make('add_user', ['messages' => $messages]);

    }

    public function getListuser()
    {
        $users = User::all();
        return View::make('list_user', ['users' => $users]);

    }

    public function getAdduser()
    {

        return View::make('add_user');
    }

    public function getEdituser($id)
    {

        return View::make('edit_user', ['user' => User::find($id)]);
    }

    public function postEdituser()
    {

        $id = intval(Input::get('id'));

        $user = [
            'name' => Input::get('name'),
            'password' => Input::get('password'),
            'email' => Input::get('email'),
            'role' => Input::get('role')
        ];

        $messages = "Record Successfully Updated";


        // Update User Record...
        try {
            User::where('id', '=', $id)
                ->update([
                    'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']
                ]);

            // If password sent update it else not

            if (Input::has('password')) {
                $user['password'] = Hash::make($user['password']);
                User::where('email', '=', $user['email'])
                    ->update(['password' => $user['password']]);
            }
        } catch (Exception $e) {
            echo $messages = 'Please enter a unique email address';
        }

        Session::put('messages', $messages);
        return Redirect::to("edituser/$id")->with('user', User::find($id));

    }

    public function getCharts()
    {
        return View::make('charts');
    }

    public function getLogout()
    {
        Session::put('action', Input::old('action'));

        Auth::logout();
        return Redirect::to('login');

    }

    public function getLogin()
    {
        if (Auth::check()) {
            return Redirect::to('/');
        }

        if (Request::Ajax()) {
            return Response::json([
                'template' => View::make('login')->render(),
                'action' => Session::get('action')
            ]);
        }

        return View::make('login');
    }

    public function anyAjax()
    {
        $requested = Input::get('requested');

        if (!Request::Ajax() || empty($requested)) {
            return App::abort(404);
        }

        $method = Request::method();

        $requested = preg_replace('#\/+#', '/', str_replace(url(''), '', $requested));

        $requested = array_values(array_filter(explode('/', $requested), 'strlen'));

        if (isset($requested[0])) {
            $requested = $requested[0];
        }

        $params = [];

        if (count($requested) > 1) {
            $params = array_slice($requested, 1);
        }

        if (empty($requested)) {
            $requested = "Index";
        }

        $requested = camel_case('@' . strtolower($method) . '_' . $requested);
        return Redirect::action(__CLASS__ . $requested, $params)->withInput();
    }

}
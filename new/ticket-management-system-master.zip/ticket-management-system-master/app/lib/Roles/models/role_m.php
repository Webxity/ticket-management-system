<?php
namespace Webxity\Roles;

use Illuminate\Support\Facades\View;
use Eloquent;

class Role_m extends Eloquent{

    protected $table = 'roles';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	//protected $hidden = array('password', 'remember_toke');
    

}